from flask import Flask, render_template, jsonify, request
import json
import os
from datetime import datetime, timedelta
import random

app = Flask(__name__)

DATA_FILE = 'game_data.json'

DEFAULT_GAME_DATA = {
    "player": {
        "name": "VANSH SHARMA",
        "level": 1,
        "current_xp": 0,
        "xp_to_next_level": 100,
        "energy": 100,
        "max_energy": 100,
        "coins": 0
    },
    "timer": {
        "hours": 4,
        "minutes": 43,
        "seconds": 0
    },
    "last_reset": "",
    "quests": {
        "strength_training": {
            "progress": 0,
            "goal": 100,
            "reward": 50
        },
        "discipline": {
            "progress": 0,
            "goal": 100,
            "reward": 50
        }
    }
}
# --- Quest Completion ---
@app.route('/api/complete_quest', methods=['POST'])
def complete_quest():
    data = load_game_data()
    player = data["player"]
    quest = request.json
    xp_gain = quest.get("xp", 0)
    coin_gain = quest.get("coins", 0)

    player["current_xp"] += xp_gain
    player["coins"] += coin_gain
    data["player"]["total_experience"] += xp_gain

    check_level_up()

    # Update stats based on quest type
    if quest["type"] == "strength":
        player["str"] += 1
    elif quest["type"] == "intelligence":
        player["int"] += 1
    elif quest["type"] == "discipline":
        player["agi"] += 1
    elif quest["type"] == "spiritual":
        player["vit"] += 1
    elif quest["type"] == "secret":
        player["per"] += 1
    elif quest["type"] == "shadow":
        player["str"] += 2
        player["vit"] += 2
        player["int"] += 2
        player["agi"] += 2
        player["per"] += 2

    save_game_data(data)
    return jsonify({"message": "Quest completed", "player": player})


# --- Streak System ---
@app.route('/api/complete_daily_task', methods=['POST'])
def complete_daily_task():
    data = load_game_data()
    data["player"]["streak"] += 1
    save_game_data(data)
    return jsonify({"message": "Daily task completed", "streak": data["player"]["streak"]})


@app.route('/api/reset_streak', methods=['POST'])
def reset_streak():
    data = load_game_data()
    data["player"]["streak"] = 0
    data["player"]["current_xp"] = max(0, data["player"]["current_xp"] - 50)
    save_game_data(data)
    return jsonify({"message": "Streak reset", "streak": 0})
    # --- Shop System ---
@app.route('/api/shop', methods=['GET'])
def get_shop_items():
    shop_items = [
        {"id": "elixir", "name": "XP Elixir", "cost": 100, "effect": "Gain 200 XP"},
        {"id": "scroll", "name": "Scroll of INT", "cost": 150, "effect": "Increase INT by 2"},
        {"id": "blade", "name": "Shadow Blade", "cost": 500, "effect": "Increase STR by 5"},
    ]
    return jsonify(shop_items)


@app.route('/api/buy_item', methods=['POST'])
def buy_item():
    data = load_game_data()
    player = data["player"]
    item = request.json
    cost = item.get("cost", 0)
    
    if player["coins"] < cost:
        return jsonify({"error": "Not enough coins"}), 400

    player["coins"] -= cost
    player["inventory"].append(item["name"])

    # Apply item effects
    if item["id"] == "elixir":
        player["current_xp"] += 200
    elif item["id"] == "scroll":
        player["int"] += 2
    elif item["id"] == "blade":
        player["str"] += 5

    check_level_up()
    save_game_data(data)
    return jsonify({"message": f"{item['name']} purchased!", "player": player})


# --- Achievements System ---
@app.route('/api/achievements', methods=['GET'])
def get_achievements():
    data = load_game_data()
    achievements = []

    if data["player"]["level"] >= 10:
        achievements.append("Rookie Hunter")
    if data["player"]["level"] >= 50:
        achievements.append("Elite Hunter")
    if data["player"]["level"] >= 100:
        achievements.append("Shadow Monarch")

    return jsonify({"achievements": achievements})
    # --- Leaderboard (Mock) ---
@app.route('/api/leaderboard', methods=['GET'])
def leaderboard():
    data = load_game_data()
    return jsonify([
        {"name": data["player"]["name"], "level": data["player"]["level"], "xp": data["player"]["current_xp"]}
    ])


# --- Utility Functions ---
def load_game_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w') as f:
            json.dump(DEFAULT_GAME_DATA, f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_game_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


@app.route('/')
def home():
    return "Hello from Solo Leveler!"


# --- Start the Flask App ---
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)